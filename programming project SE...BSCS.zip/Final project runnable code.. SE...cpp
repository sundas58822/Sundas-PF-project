#include <iostream>
#include <fstream>
using namespace std;

struct Courses {
    int courseID;
    string CourseName;
};

struct Student {
    int StudentID;
    string StudentName;
    string gender;
    int semester;
};

int studentCount = 0;
int courseCount = 0;

// Color codes
#define RESET   "\033[0m"
#define RED     "\033[1;31m"
#define GREEN   "\033[1;32m"
#define YELLOW  "\033[1;33m"
#define BLUE    "\033[1;34m"
#define MAGENTA "\033[1;35m"
#define CYAN    "\033[1;36m"

void addStudent(Student students[]) {
    cout << GREEN << "Enter Student ID for student " << studentCount + 1 << ": " << RESET;
    cin >> students[studentCount].StudentID;

    cout << GREEN << "Enter name for student " << studentCount + 1 << ": " << RESET;
    cin.ignore();
    getline(cin, students[studentCount].StudentName);

    cout << GREEN << "Enter gender for student " << studentCount + 1 << ": " << RESET;
    cin >> students[studentCount].gender;

    cout << GREEN << "Enter semester for student " << studentCount + 1 << ": " << RESET;
    cin >> students[studentCount].semester;

    studentCount++;

    ofstream outFile("student_data.txt", ios::app);
    if (!outFile.is_open()) {
        cout << RED << "Error: Unable to open file for writing." << RESET << endl;
        return;
    }

    outFile << "Student ID: " << students[studentCount - 1].StudentID << endl;
    outFile << "Name: " << students[studentCount - 1].StudentName << endl;
    outFile << "Gender: " << students[studentCount - 1].gender << endl;
    outFile << "Semester: " << students[studentCount - 1].semester << endl;
    outFile << endl;

    outFile.close();
}

void displayStudents(Student students[]) {
    for (int i = 0; i < studentCount; i++) {
        cout << BLUE << "Student ID: " << RESET << students[i].StudentID
             << ", " << BLUE << "Name: " << RESET << students[i].StudentName
             << ", " << BLUE << "Gender: " << RESET << students[i].gender
             << ", " << BLUE << "Semester: " << RESET << students[i].semester << endl;
    }
}

void deleteStudent(Student students[]) {
    int id;
    cout << RED << "Enter the ID of the student you want to delete: " << RESET;
    cin >> id;
    for (int i = 0; i < studentCount; i++) {
        if (students[i].StudentID == id) {
            for (int j = i; j < studentCount - 1; j++) {
                students[j] = students[j + 1];
            }
            studentCount--;
            cout << GREEN << "Student with ID " << id << " deleted successfully." << RESET << endl;
            return;
        }
    }
    cout << RED << "Student with ID " << id << " not found." << RESET << endl;
}

void searchStudent(Student students[]) {
    int id;
    cout << YELLOW << "Enter the ID of the student you want to search: " << RESET;
    cin >> id;
    for (int i = 0; i < studentCount; i++) {
        if (students[i].StudentID == id) {
            cout << "\n" << GREEN << "************" << RESET << "\n";
            cout << GREEN << "Student with ID " << id << " found at index " << i << "." << RESET << endl;
            cout << GREEN << "Student Information:" << RESET << endl;
            cout << BLUE << "Student ID: " << RESET << students[i].StudentID << endl;
            cout << BLUE << "Name: " << RESET << students[i].StudentName << endl;
            cout << BLUE << "Gender: " << RESET << students[i].gender << endl;
            cout << BLUE << "Semester: " << RESET << students[i].semester << endl;
            cout << "\n" << GREEN << "************" << RESET << "\n";
            return;
        }
    }
    cout << RED << "Student with ID " << id << " not found." << RESET << endl;
}

void updateStudent(Student students[]) {
    int id;
    cout << YELLOW << "Enter the ID of the student you want to update: " << RESET;
    cin >> id;
    for (int i = 0; i < studentCount; i++) {
        if (students[i].StudentID == id) {
            cout << BLUE << "Enter new Student Name: " << RESET;
            cin.ignore();
            getline(cin, students[i].StudentName);

            cout << BLUE << "Enter new Gender: " << RESET;
            cin >> students[i].gender;

            cout << BLUE << "Enter new Semester: " << RESET;
            cin >> students[i].semester;

            cout << GREEN << "Student information updated successfully!" << RESET << endl;
            return;
        }
    }
    cout << RED << "Student with ID " << id << " not found." << RESET << endl;
}
//add courses 
void addCourses(Courses courses[]) {
    if (courseCount >= 5) {
        cout << "Maximum number of courses reached!" << endl;
        return;
    }
    
    cout << "\nEnter Course ID for course " << courseCount + 1 << ": ";
    cin >> courses[courseCount].courseID;

    cout << "Enter name for course " << courseCount + 1 << ": ";
    cin.ignore(); 
    getline(cin, courses[courseCount].CourseName);

    courseCount++;
    
    ofstream outFile("course_data.txt", ios::app); 
    if (!outFile.is_open()) {
        cout << "Error: Unable to open file for writing." << endl;
        return;
    }
    
    outFile << "Course ID: " << courses[courseCount - 1].courseID << endl; //aik course m aik index ho
    outFile << "Name: " << courses[courseCount - 1].CourseName << endl;
    outFile << endl; 

    outFile.close(); 
}
// display courses 
void displayCourses(Courses courses[]) {
    for (int i = 0; i < courseCount; i++) {
        cout << "Course ID: " << courses[i].courseID;
		cout<< ", Name: " << courses[i].CourseName;
    }
}
// delete courses
void deleteCourses(Courses courses[]) {
    int id;
    cout << "Enter the ID of the course you want to delete: ";
    cin >> id;
    for (int i = 0; i < courseCount; i++) {
        if (courses[i].courseID == id) {
            for (int j = i; j < courseCount - 1; j++) {
                courses[j] = courses[j + 1];
            }
            courseCount--;
            cout << "Course with ID " << id << " deleted successfully." << endl;
            return;
        }
    }
    cout << "Course with ID " << id << " not found." << endl;
}

void searchCourse(Courses courses[]) {
    int id;
    cout << "Enter the ID of the course you want to search: ";
    cin >> id;
    for (int i = 0; i < courseCount; i++) {
        if (courses[i].courseID == id) {
        	cout<<"\n************\n";
            cout << "Course with ID " << id << " found at index " << i << "." << endl;
            cout << "Course Information:" << endl;
            cout << "Course ID: " << courses[i].courseID << endl;
            cout << "Name: " << courses[i].CourseName << endl;
            cout<<"\n************\n";
            return;
        }
    }
    cout << "Course with ID " << id << " not found." << endl;
}

void updateCourses(Courses courses[]) {
    int id;
    cout << "Enter the ID of the course you want to update: ";
    cin >> id;
    for (int i = 0; i < courseCount; i++) {
        if (courses[i].courseID == id) {
            cout << "Enter new Course Name: ";
            cin.ignore();
            getline(cin, courses[i].CourseName);

            cout << "Course information updated successfully!" << endl;
            return;
        }
    }
    cout << "Course with ID " << id << " not found." << endl;
}
int main() {
    cout << MAGENTA << "\t\t\t\t\t~~~WELCOME TO SCHOOL MANAGEMENT SYSTEM~~ " << RESET << endl;
    Student st[100];
    Courses cr[100];
    string user = "admin", password = "123", u, p;

    cout << YELLOW << "\t\t\t\t\tEnter UserName: " << RESET;
    cin >> u;
    cout << YELLOW << "\t\t\t\t\tEnter Password: " << RESET;
    cin >> p;

    if (user == u && password == p) {
        cout << GREEN << "Login Successfully!!!" << RESET << endl;
        while (1) {
            int m;
            cout << "\n" << CYAN << "1-Admin\n" << RESET;
            cout << CYAN << "2-Students\n" << RESET;
            cout << CYAN << "3-Exit\n" << RESET;
            cin >> m;

            if (m == 1) {
                int n = 1;
                while (n == 1) {
                    int ch;
                    cout << "\n" << BLUE << "1-Admin\n" << RESET;
                    cout << BLUE << "1-Add Student\n" << RESET;
                    cout << BLUE << "2-Add Courses\n" << RESET;
                    cout << BLUE << "3-DELETE Student\n" << RESET;
                    cout << BLUE << "4-DELETE Courses\n" << RESET;
                    cout << BLUE << "5-UPDATE Student\n" << RESET;
                    cout << BLUE << "6-UPDATE Courses\n" << RESET;
                    cout << BLUE << "7-SEARCH Student\n" << RESET;
                    cout << BLUE << "8-SEARCH Courses\n" << RESET;
                    cout << BLUE << "9-VIEW Student\n" << RESET;
                    cout << BLUE << "10-VIEW Courses\n" << RESET;
                    cin >> ch;

                    switch (ch) {
                         case 1:
                        addStudent(st);
                        break;
                    case 2:
                        addCourses(cr);
                        break;
                    case 3:
                        deleteStudent(st);
                        break;
                    case 4:
                        deleteCourses(cr);
                        break;
                    case 5:
                        updateStudent(st);
                        break;
                    case 6:
                        updateCourses(cr);
                        break;
                    case 7:
                        searchStudent(st);
                        break;
                    case 8:
                        searchCourse(cr);
                        break;
                    case 9:
                        displayStudents(st);
                        break;
                    case 10:
                        displayCourses(cr);
                        break;
                        default: cout << RED << "Invalid choice! Please enter a valid option." << RESET << endl;
                    }
                    cout << GREEN << "Do you want to Run again? Enter 1 for Yes: " << RESET;
                    cin >> n;
                }
            }
            else if (m == 2) {
                int n = 1;
                while (n == 1) {
                    int ch;
                    cout << CYAN << "Students\n" << RESET;
                    cout << CYAN << "1-View Students\n" << RESET;
                    cout << CYAN << "2-View Courses\n" << RESET;
                    cin >> ch;
                    if (ch == 1) {
                        displayStudents(st);
                    }
                    else if (ch == 2) {
                        // display courses code here
                    }
                    cout << GREEN << "Do you want to Run again? Enter 1 for Yes: " << RESET;
                    cin >> n;
                }
            }
            else if (m == 3) {
                return 0;
            }
            else {
                cout << RED << "Invalid Option!" << RESET << endl;
            }
        }
    }
    else {
        cout << RED << "Invalid Username or Password!" << RESET << endl;
    }
    return 0;
}

